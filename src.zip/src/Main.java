import modelo.conexion;
import vista.vista;

public class Main {
    public static void main(String[] args) {
        vista view = new vista();
        view.Conectar();
    }
}